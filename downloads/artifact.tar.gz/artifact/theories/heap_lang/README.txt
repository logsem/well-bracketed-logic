The files in this directory are taken from the iris developemnt and adapted to work with WBWP's instead of WP's.
