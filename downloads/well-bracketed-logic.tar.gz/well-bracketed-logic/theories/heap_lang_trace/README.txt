The files in this directory are taken from the framework from "Theorems for Free
from Separation Logic Specifications" by Birkedal et al. (ICFP'21), but
adapted to work with WBWP's instead of WP.
